#ifndef KEYBOARD_ASM_H
#define KEYBOARD_ASM_H
#include <stdint.h>

uint8_t keyActivated();
uint8_t getKeyCode();


#endif
