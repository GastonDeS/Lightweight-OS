#ifndef DATE_ASM_H
#define DATE_ASM_H
#include <stdint.h>

uint64_t getTimeInfo(uint8_t mod);

#endif
