#ifndef IDT_LOADER_H
#define IDT_LOADER_H

void load_idt();

#endif
