#ifndef  TIMER_H
#define TIMER_H

#include <stdint.h>

int readSeconds();
int readMinutes();
int readHours();
int readDays();
int readMonths();
int readYear();
int totalTics();

#endif