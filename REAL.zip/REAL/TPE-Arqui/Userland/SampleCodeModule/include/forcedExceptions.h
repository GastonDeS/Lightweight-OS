#ifndef FORCED_EXC_H
#define FORCED_EXC_H

void forceDivZero();
void forceInvalidOPCode();

#endif
