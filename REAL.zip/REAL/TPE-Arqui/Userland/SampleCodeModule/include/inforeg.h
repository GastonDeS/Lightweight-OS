#ifndef INFOREG_H
#define INFOREG_H
#include <stdint.h>

void getRegisters(uint64_t * registers);
#endif
